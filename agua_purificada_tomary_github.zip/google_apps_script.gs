// Google Apps Script: registra los pedidos recibidos en Google Sheets.
const SPREADSHEET_ID = "PEGA_AQUI_EL_ID_DE_TU_GOOGLE_SHEET";
const SHEET_NAME = "Pedidos";

function doPost(e) {
  try {
    const data = JSON.parse((e && e.postData && e.postData.contents) || "{}");
    const ss = SpreadsheetApp.openById(SPREADSHEET_ID);
    let sheet = ss.getSheetByName(SHEET_NAME);
    if (!sheet) {
      sheet = ss.insertSheet(SHEET_NAME);
      sheet.appendRow(["Fecha de registro","Nombre","Celular","Ubicación de entrega","Garrafones","Latitud","Longitud"]);
      sheet.setFrozenRows(1);
    }
    sheet.appendRow([new Date(),safeCell(data.nombre),safeCell(data.celular),safeCell(data.ubicacion),Number(data.garrafones)||"",safeCell(data.latitud),safeCell(data.longitud)]);
    return ContentService.createTextOutput(JSON.stringify({ok:true})).setMimeType(ContentService.MimeType.JSON);
  } catch(err) {
    return ContentService.createTextOutput(JSON.stringify({ok:false,error:String(err)})).setMimeType(ContentService.MimeType.JSON);
  }
}
function safeCell(value) {
  const s=String(value==null?"":value).slice(0,2000);
  return /^[=+@-]/.test(s) ? "'"+s : s;
}
